# RASA

A simple supplier/buyer lead-intake website with a private Supabase admin panel.

## Files
- `index.html`: public supplier/buyer forms and admin interface.
- `database/schema.sql`: database tables and Row Level Security policies.

## Setup
1. Create a Supabase project.
2. Open SQL Editor and run `database/schema.sql`.
3. In Supabase Authentication > Users, create your own admin user with email/password.
4. Copy that user's UUID.
5. In SQL Editor run:
   ```sql
   insert into public.admin_users (user_id)
   values ('YOUR_AUTH_USER_UUID');
   ```
6. Open `index.html` and replace:
   - `YOUR_SUPABASE_URL`
   - `YOUR_SUPABASE_ANON_KEY`
   with values from Supabase Project Settings > API.
7. Upload `index.html` to the root of a GitHub repository and enable GitHub Pages.

## Security notes
- The anon/publishable key is intended for browser use; never put the Supabase `service_role` secret in this file.
- Public visitors can INSERT submissions only. They cannot SELECT submitted records.
- Only UUIDs listed in `admin_users` can read/update/delete submissions.
- This starter does not include CAPTCHA, rate limiting, file uploads, email notifications, or payment/commission collection. Add abuse protection before public launch.
- Use a real business contact number and publish an appropriate privacy notice before collecting personal information.
