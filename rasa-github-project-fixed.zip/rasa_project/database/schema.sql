-- RASA database schema for Supabase
-- Run this entire file in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.supplier_submissions (
  id uuid primary key default gen_random_uuid(),
  brand text not null check (char_length(brand) between 1 and 100),
  company text not null default '',
  product text not null check (char_length(product) between 1 and 120),
  category text not null,
  price text not null default '',
  minimum_order text not null default '',
  city text not null,
  phone text not null,
  description text not null,
  status text not null default 'new'
    check (status in ('new','reviewed','contacted','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.buyer_requests (
  id uuid primary key default gen_random_uuid(),
  buyer_name text not null,
  product text not null,
  quantity text not null,
  city text not null,
  phone text not null,
  budget text not null default '',
  details text not null default '',
  status text not null default 'new'
    check (status in ('new','reviewed','contacted','matched','closed')),
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.supplier_submissions enable row level security;
alter table public.buyer_requests enable row level security;

-- Helper checks membership in the private admin allow-list.
create or replace function public.is_rasa_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.admin_users a
    where a.user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_rasa_admin() from public;
grant execute on function public.is_rasa_admin() to authenticated;

-- Public visitors may submit forms, but cannot read submitted data.
drop policy if exists "Public can submit supplier form" on public.supplier_submissions;
create policy "Public can submit supplier form"
on public.supplier_submissions for insert to anon, authenticated
with check (
  char_length(brand) between 1 and 100
  and char_length(product) between 1 and 120
  and char_length(phone) between 5 and 30
);

drop policy if exists "Admins manage supplier submissions" on public.supplier_submissions;
create policy "Admins manage supplier submissions"
on public.supplier_submissions for all to authenticated
using (public.is_rasa_admin())
with check (public.is_rasa_admin());

drop policy if exists "Public can submit buyer requests" on public.buyer_requests;
create policy "Public can submit buyer requests"
on public.buyer_requests for insert to anon, authenticated
with check (
  char_length(buyer_name) between 1 and 120
  and char_length(product) between 1 and 120
  and char_length(phone) between 5 and 30
);

drop policy if exists "Admins manage buyer requests" on public.buyer_requests;
create policy "Admins manage buyer requests"
on public.buyer_requests for all to authenticated
using (public.is_rasa_admin())
with check (public.is_rasa_admin());

-- No public read policy exists. Admin allow-list itself is not readable by anon.
drop policy if exists "Admins read admin list" on public.admin_users;
create policy "Admins read admin list"
on public.admin_users for select to authenticated
using (public.is_rasa_admin());

grant insert on public.supplier_submissions to anon, authenticated;
grant insert on public.buyer_requests to anon, authenticated;
grant select, update, delete on public.supplier_submissions to authenticated;
grant select, update, delete on public.buyer_requests to authenticated;
grant select on public.admin_users to authenticated;

-- IMPORTANT: Do not add an admin through the public website.
-- Create your own user in Supabase Authentication > Users, then copy its UUID.
-- Add that UUID using this SQL:
-- insert into public.admin_users (user_id)
-- values ('YOUR_AUTH_USER_UUID');
